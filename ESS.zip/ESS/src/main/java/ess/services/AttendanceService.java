package ess.services;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ess.dao.AttendanceDao;
import ess.model.Attendance;

@Service
public class AttendanceService {
	@Autowired
	private AttendanceDao attendanceDao;

	public void save(Attendance attend) {
		attendanceDao.addAttendance(attend);
	}

	public Attendance getAttendance(int userid, LocalDate date) {
		return attendanceDao.getAttendance(userid, date);
	}

	public List<Attendance> getAttendanceByMonth(int userid, LocalDate startDate) {
		return attendanceDao.getAttendanceByMonth(userid, startDate);
	}
}
