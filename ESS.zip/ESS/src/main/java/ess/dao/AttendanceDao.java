package ess.dao;

import java.time.LocalDate;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;

import ess.model.Attendance;

@Repository
public class AttendanceDao {
	@Autowired
	private HibernateTemplate ht;

	@Transactional
	public void addAttendance(Attendance attend) {
		this.ht.saveOrUpdate(attend);
	}

	public Attendance getAttendance(int userid, LocalDate date) {
		@SuppressWarnings({ "deprecation", "unchecked" })
		List<Attendance> attendanceList = (List<Attendance>) this.ht.findByNamedParam(
				"FROM Attendance WHERE userid = :userid AND date = :date", new String[] { "userid", "date" },
				new Object[] { userid, date });

		return attendanceList.isEmpty() ? null : attendanceList.get(0);
	}

	public List<Attendance> getAttendanceByMonth(int userid, LocalDate date) {
		int month = date.getMonthValue();
		int year = date.getYear();

		String hqlQuery = "FROM Attendance WHERE userid = :userid " + "AND MONTH(date) = :month AND YEAR(date) = :year";

		@SuppressWarnings({ "unchecked", "deprecation" })
		List<Attendance> attendanceList = (List<Attendance>) this.ht.findByNamedParam(hqlQuery,
				new String[] { "userid", "month", "year" }, new Object[] { userid, month, year });

		return attendanceList;
	}

}
