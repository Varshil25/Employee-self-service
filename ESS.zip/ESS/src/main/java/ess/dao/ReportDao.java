package ess.dao;

import ess.model.Report;

public interface ReportDao {
	Report getReport(String name);
}
