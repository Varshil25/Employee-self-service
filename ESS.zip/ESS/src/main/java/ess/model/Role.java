package ess.model;

public enum Role {
	Admin,
	Employee;	
}
